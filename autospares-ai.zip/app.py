import os, json, secrets
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXT   = {'png','jpg','jpeg','gif','webp','pdf'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

MAIL_CFG    = os.path.join(BASE_DIR, 'mail_config.json')
API_CFG     = os.path.join(BASE_DIR, 'api_config.json')
DS_AUDIT    = os.path.join(BASE_DIR, 'ds_audit.json')

def load_mail_cfg():
    if os.path.exists(MAIL_CFG):
        try:
            with open(MAIL_CFG) as f: return json.load(f)
        except: pass
    return {'username': os.environ.get('MAIL_USERNAME',''), 'password': os.environ.get('MAIL_PASSWORD',''), 'enabled': True}

def save_mail_cfg(username, password, enabled=True):
    with open(MAIL_CFG,'w') as f: json.dump({'username':username,'password':password,'enabled':enabled},f)

def load_api_cfg():
    if os.path.exists(API_CFG):
        try:
            with open(API_CFG) as f: return json.load(f)
        except: pass
    return {'api_key': os.environ.get('ANTHROPIC_API_KEY','')}

def save_api_cfg(api_key):
    with open(API_CFG,'w') as f: json.dump({'api_key': api_key}, f)
    os.environ['ANTHROPIC_API_KEY'] = api_key

def get_api_key():
    cfg = load_api_cfg()
    return cfg.get('api_key') or os.environ.get('ANTHROPIC_API_KEY','')

def log_ds_audit(action, target, reason, admin_name):
    logs = []
    if os.path.exists(DS_AUDIT):
        try:
            with open(DS_AUDIT) as f: logs = json.load(f)
        except: pass
    logs.insert(0, {'action': action, 'target': target, 'reason': reason,
                     'admin': admin_name, 'time': datetime.now().strftime('%d %b %Y, %I:%M %p')})
    logs = logs[:200]
    with open(DS_AUDIT,'w') as f: json.dump(logs, f)

app = Flask(__name__,
    template_folder=os.path.join(BASE_DIR,'templates'),
    static_folder=os.path.join(BASE_DIR,'static'))
app.config['SECRET_KEY']                     = 'autospares-secret-2024'
app.config['SQLALCHEMY_DATABASE_URI']        = 'sqlite:///' + os.path.join(BASE_DIR,'autospares.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER']                  = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH']             = 16*1024*1024

_mc = load_mail_cfg()
app.config['MAIL_SERVER']         = 'smtp.gmail.com'
app.config['MAIL_PORT']           = 587
app.config['MAIL_USE_TLS']        = True
app.config['MAIL_USERNAME']       = _mc['username']
app.config['MAIL_PASSWORD']       = _mc['password']
app.config['MAIL_DEFAULT_SENDER'] = _mc['username'] or 'noreply@autospares.com'

db            = SQLAlchemy(app)
login_manager = LoginManager(app)
mail          = Mail(app)
login_manager.login_view = 'login'

# ── MODELS ────────────────────────────────────────────────────────────────────────
class User(UserMixin, db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.String(20), unique=True, nullable=True)
    name        = db.Column(db.String(100), nullable=False)
    email       = db.Column(db.String(120), unique=True, nullable=False)
    password    = db.Column(db.String(200), nullable=False)
    role        = db.Column(db.String(20), default='customer')
    phone       = db.Column(db.String(20))
    car_model   = db.Column(db.String(100))
    car_year    = db.Column(db.String(10))
    car_reg     = db.Column(db.String(30))
    address     = db.Column(db.String(200))
    created_at  = db.Column(db.DateTime, default=datetime.now)
    reset_token = db.Column(db.String(100), nullable=True)
    orders      = db.relationship('Order', backref='customer', lazy=True, foreign_keys='Order.customer_id')

class LoginLog(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user       = db.relationship('User', foreign_keys=[user_id])
    role       = db.Column(db.String(20))
    login_time = db.Column(db.DateTime, default=datetime.now)
    ip_address = db.Column(db.String(45))

class Part(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    brand      = db.Column(db.String(50))
    category   = db.Column(db.String(50))
    price      = db.Column(db.Float, default=0)
    stock      = db.Column(db.Integer, default=0)
    compatible = db.Column(db.Text)

class Order(db.Model):
    id              = db.Column(db.Integer, primary_key=True)
    customer_id     = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    items_json      = db.Column(db.Text)
    total_price     = db.Column(db.Float)
    status          = db.Column(db.String(30), default='pending')
    close_reason    = db.Column(db.Text)
    deadline        = db.Column(db.String(50))
    appointment     = db.Column(db.String(50))
    notes           = db.Column(db.Text)
    delivery_method = db.Column(db.String(20))   # showroom / courier
    courier_name    = db.Column(db.String(100))
    tracking_id     = db.Column(db.String(100))
    created_at      = db.Column(db.DateTime, default=datetime.now)
    STATUS_LABELS = {
        'pending':          ('🕐','Pending Review','warning'),
        'checking':         ('🔍','Under Checking','info'),
        'processing':       ('⚙️','Order Processing','primary'),
        'packing':          ('📦','Packing Order','info'),
        'received':         ('✅','Parts Ready','success'),
        'appointment_set':  ('📅','Appointment Scheduled','success'),
        'out_for_delivery': ('🚚','Out for Delivery','primary'),
        'delivered':        ('🎉','Delivered','success'),
        'closed':           ('❌','Order Closed','danger'),
    }
    def status_display(self): return self.STATUS_LABELS.get(self.status,('❓',self.status,'secondary'))
    def items(self):
        try: return json.loads(self.items_json or '[]')
        except: return []

class PartRequest(db.Model):
    id               = db.Column(db.Integer, primary_key=True)
    customer_id      = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    customer         = db.relationship('User', foreign_keys=[customer_id])
    part_name        = db.Column(db.String(100), nullable=False)
    part_number      = db.Column(db.String(60))
    brand_pref       = db.Column(db.String(60))
    car_model        = db.Column(db.String(100))
    car_year         = db.Column(db.String(10))
    car_reg          = db.Column(db.String(30))
    urgency          = db.Column(db.String(20), default='normal')
    quantity         = db.Column(db.Integer, default=1)
    description      = db.Column(db.Text)
    attachment       = db.Column(db.String(200))
    status           = db.Column(db.String(20), default='open')
    admin_reply      = db.Column(db.Text)
    admin_attachment = db.Column(db.String(200))
    estimated_price  = db.Column(db.Float, nullable=True)
    created_at       = db.Column(db.DateTime, default=datetime.now)
    STATUS_MAP = {
        'open':         ('🟡','Open','warning'),
        'acknowledged': ('🔵','Acknowledged','info'),
        'sourcing':     ('🟠','Sourcing','primary'),
        'closed':       ('⚫','Closed','secondary'),
    }
    def status_display(self): return self.STATUS_MAP.get(self.status,('❓',self.status,'secondary'))

class Ticket(db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    customer    = db.relationship('User', foreign_keys=[customer_id])
    order_id    = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    category    = db.Column(db.String(40), default='general')
    subject     = db.Column(db.String(200), nullable=False)
    message     = db.Column(db.Text, nullable=False)
    priority    = db.Column(db.String(10), default='normal')
    status      = db.Column(db.String(20), default='open')
    admin_reply = db.Column(db.Text)
    attachment  = db.Column(db.String(200))
    reopen_reason = db.Column(db.Text)
    created_at  = db.Column(db.DateTime, default=datetime.now)
    CATEGORY_LABELS = {
        'general':'💬 General Query','order_issue':'📦 Order Issue',
        'delivery':'🚚 Delivery / Appointment','payment':'💳 Payment',
        'wrong_part':'🔄 Wrong / Damaged Part','billing':'🧾 Bill / Invoice','other':'❓ Other',
    }
    PRIORITY_MAP = {'low':'secondary','normal':'info','high':'danger'}
    STATUS_MAP   = {'open':'warning','replied':'success','closed':'secondary'}
    def priority_color(self): return self.PRIORITY_MAP.get(self.priority,'secondary')
    def status_color(self):   return self.STATUS_MAP.get(self.status,'secondary')
    def category_label(self): return self.CATEGORY_LABELS.get(self.category,self.category)

@login_manager.user_loader
def load_user(uid): return db.session.get(User,int(uid))

# ── HELPERS ───────────────────────────────────────────────────────────────────────
def allowed_file(fn): return '.' in fn and fn.rsplit('.',1)[1].lower() in ALLOWED_EXT

def save_upload(field):
    f = request.files.get(field)
    if f and f.filename and allowed_file(f.filename):
        fn = secrets.token_hex(8)+'_'+secure_filename(f.filename)
        f.save(os.path.join(UPLOAD_FOLDER,fn)); return fn
    return None

def parts_context():
    lines = ["ID|Name|Brand|Category|Price|Stock|Compatible"]
    for p in Part.query.all():
        lines.append(f"{p.id}|{p.name}|{p.brand}|{p.category}|Rs{p.price}|{p.stock}|{p.compatible}")
    return "\n".join(lines)

def send_mail(to, subject, html_body, text_body=None):
    cfg = load_mail_cfg()
    if not cfg.get('enabled',True): print(f"[MAIL DISABLED] {subject}"); return
    if not cfg.get('username'):     print(f"[MAIL SKIPPED] {subject}"); return
    try:
        app.config['MAIL_USERNAME'] = cfg['username']
        app.config['MAIL_PASSWORD'] = cfg['password']
        app.config['MAIL_DEFAULT_SENDER'] = cfg['username']
        with app.app_context():
            m = Mail(app)
            msg = Message(subject, recipients=[to],
                          sender=('"AutoSpares" <'+cfg['username']+'>'),
                          html=html_body, body=text_body or '')
            m.send(msg)
        print(f"[MAIL SENT] To:{to}")
    except Exception as e: print(f"[MAIL ERROR] {e}")

def mail_html(title, greeting, body_html, cta_text=None, cta_url=None):
    cta = f'<div style="text-align:center;margin:28px 0"><a href="{cta_url}" style="background:#e8a020;color:#000;padding:14px 32px;border-radius:8px;font-weight:700;text-decoration:none;font-size:16px">{cta_text}</a></div>' if cta_text else ''
    return f"""<!DOCTYPE html><html><body style="margin:0;padding:0;background:#0d0f12;font-family:Arial,sans-serif">
<div style="max-width:560px;margin:30px auto;background:#161a22;border-radius:14px;overflow:hidden;border:1px solid #242830">
  <div style="background:linear-gradient(135deg,#1a1e2a,#222840);padding:30px 36px;border-bottom:3px solid #e8a020">
    <div style="font-size:28px;font-weight:900;letter-spacing:3px;color:#e8a020">AUTO<span style="color:#e2e4e8">SPARES</span></div>
    <div style="color:#9ca3af;font-size:14px;margin-top:6px">{title}</div>
  </div>
  <div style="padding:32px 36px;color:#e2e4e8;font-size:15px;line-height:1.7">
    <p style="margin:0 0 20px;font-size:16px">{greeting}</p>
    {body_html}{cta}
    <p style="font-size:12px;color:#6b7280;margin-top:32px;border-top:1px solid #242830;padding-top:18px">
      AutoSpares — AI-Powered Auto Parts | This is an automated email, please do not reply.
    </p>
  </div>
</div></body></html>"""

def log_login(user):
    try:
        db.session.add(LoginLog(user_id=user.id,role=user.role,ip_address=request.remote_addr))
        db.session.commit()
    except: pass

def generate_bill_html(order):
    items = order.items()
    rs = '&#8377;'
    rows = ''.join(
        f'<tr>'
        f'<td style="padding:12px 16px;border-bottom:1px solid #e5e7eb">'
        f'<div style="font-weight:600;font-size:15px;color:#1f2937">{i["name"]}</div>'
        f'<div style="font-size:12px;color:#9ca3af">{i.get("brand","")}</div>'
        f'</td>'
        f'<td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:15px">{i["qty"]}</td>'
        f'<td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;text-align:right;font-size:15px">{rs}{i["price"]:.0f}</td>'
        f'<td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;text-align:right;font-size:15px;color:#d97706;font-weight:700">{rs}{i["price"]*i["qty"]:.0f}</td>'
        f'</tr>'
        for i in items
    )
    car_info = f"{order.customer.car_model or 'Not specified'} {order.customer.car_year or ''}".strip()
    delivery_html = ''
    if order.delivery_method == 'showroom':
        delivery_html = '<span style="background:#dcfce7;color:#16a34a;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700">&#128205; Showroom Pickup</span>'
        if order.appointment:
            delivery_html += f'<div style="margin-top:8px;font-size:14px;color:#6b7280">Appointment: <strong style="color:#1f2937">{order.appointment}</strong></div>'
    elif order.delivery_method == 'courier':
        delivery_html = '<span style="background:#dbeafe;color:#1d4ed8;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700">&#128666; Courier Delivery</span>'
        if order.courier_name:
            delivery_html += f'<div style="margin-top:8px;font-size:14px;color:#6b7280">Courier: <strong>{order.courier_name}</strong>'
            if order.tracking_id:
                delivery_html += f' &bull; Tracking: <strong style="font-family:monospace;color:#1f2937">{order.tracking_id}</strong>'
            delivery_html += '</div>'
    phone_row = f'<div style="font-size:14px;color:#6b7280">{order.customer.phone}</div>' if order.customer.phone else ''
    addr_row  = f'<div style="font-size:14px;color:#6b7280">{order.customer.address}</div>' if order.customer.address else ''
    delivery_section = f"""<tr><td colspan="4" style="padding:16px 0 0">
      <div style="font-size:11px;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Delivery</div>
      {delivery_html}
    </td></tr>""" if delivery_html else ''

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Invoice INV-{order.id:05d} - AutoSpares</title>
  <style>
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font-family:Arial,Helvetica,sans-serif;background:#f3f4f6;padding:24px;color:#1f2937}}
    .page{{max-width:720px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.12)}}
    .hdr{{background:linear-gradient(135deg,#1a1e2a,#2d3748);color:#fff;padding:36px 40px}}
    .logo{{font-size:28px;font-weight:900;letter-spacing:3px;color:#e8a020}}
    .bdy{{padding:32px 40px}}
    table{{width:100%;border-collapse:collapse}}
    th{{background:#f9fafb;padding:12px 16px;font-size:12px;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;border-bottom:2px solid #e5e7eb}}
    .ftr{{background:#f9fafb;padding:20px 40px;font-size:12px;color:#9ca3af;text-align:center;border-top:1px solid #e5e7eb}}
    @media print{{body{{background:#fff;padding:0}}.page{{box-shadow:none;border-radius:0}}.print-btn{{display:none!important}}}}
  </style>
</head>
<body>
<div class="page">
  <div class="hdr">
    <div class="logo">AUTO<span style="color:#fff">SPARES</span></div>
    <div style="color:#9ca3af;font-size:13px;margin-top:4px">AI-Powered Automobile Parts</div>
    <div style="margin-top:24px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:16px">
      <div><div style="color:#9ca3af;font-size:11px;letter-spacing:1px">INVOICE NO.</div><div style="font-size:22px;font-weight:900;color:#e8a020">INV-{order.id:05d}</div></div>
      <div><div style="color:#9ca3af;font-size:11px;letter-spacing:1px">DATE</div><div style="font-size:16px;font-weight:600">{order.created_at.strftime('%d %b %Y')}</div></div>
      <div><div style="color:#9ca3af;font-size:11px;letter-spacing:1px">STATUS</div><div style="font-size:16px;font-weight:600;color:#2ecc71">{order.status.replace("_"," ").title()}</div></div>
    </div>
  </div>
  <div class="bdy">
    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:24px;margin-bottom:28px">
      <div>
        <div style="font-size:11px;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Bill To</div>
        <div style="font-size:18px;font-weight:700;margin-bottom:4px">{order.customer.name}</div>
        <div style="font-size:14px;color:#6b7280">{order.customer.email}</div>
        {phone_row}{addr_row}
      </div>
      <div>
        <div style="font-size:11px;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Vehicle</div>
        <div style="font-size:15px;font-weight:600">{car_info}</div>
        <div style="font-size:14px;color:#6b7280">Reg: {order.customer.car_reg or 'Not provided'}</div>
        <div style="font-size:14px;color:#6b7280">Customer ID: <strong>{order.customer.customer_id or 'N/A'}</strong></div>
      </div>
    </div>
    <table>
      <thead><tr>
        <th style="text-align:left">Part Description</th>
        <th style="text-align:center">Qty</th>
        <th style="text-align:right">Unit Price</th>
        <th style="text-align:right">Amount</th>
      </tr></thead>
      <tbody>{rows}</tbody>
      <tfoot>
        {delivery_section}
        <tr style="background:#f9fafb">
          <td colspan="3" style="padding:16px;text-align:right;font-size:15px;color:#6b7280;font-weight:600;border-top:2px solid #e5e7eb">TOTAL AMOUNT</td>
          <td style="padding:16px;text-align:right;font-size:24px;color:#d97706;font-weight:900;border-top:2px solid #e5e7eb">{rs}{order.total_price:.0f}</td>
        </tr>
      </tfoot>
    </table>
    <div style="margin-top:24px;padding-top:20px;border-top:1px solid #e5e7eb;font-size:12px;color:#9ca3af;line-height:1.9">
      <strong style="color:#6b7280">Terms &amp; Conditions</strong><br>
      1. All parts carry manufacturer warranty as applicable.<br>
      2. Returns accepted within 7 days with original packaging and bill.<br>
      3. For courier orders, AutoSpares is not responsible for damage during transit.<br>
      4. This is a computer-generated invoice and is valid without a physical signature.
    </div>
  </div>
  <div class="ftr">
    AutoSpares &mdash; AI-Powered Auto Parts &nbsp;|&nbsp; Thank you for your business!
    <div style="margin-top:10px">
      <button onclick="window.print()" class="print-btn" style="background:#e8a020;color:#000;border:none;padding:8px 20px;border-radius:6px;font-weight:700;cursor:pointer;font-size:13px">&#128438; Print / Save as PDF</button>
    </div>
  </div>
</div>
</body>
</html>"""

# ── AUTH ──────────────────────────────────────────────────────────────────────────
@app.route('/')
def index(): return render_template('index.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email    = request.form.get('email','').strip()
        password = request.form.get('password','')
        portal   = request.form.get('portal','')   # 'customer' | 'company' | 'dataservice'
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            # ── PORTAL LOCK: make sure the user is logging into the right portal
            if portal and user.role != portal:
                role_labels = {'customer':'Customer Portal','company':'Company Portal','dataservice':'Data Service Portal'}
                expected = role_labels.get(user.role, user.role)
                flash(f'❌ Access Denied — Your account ({user.role}) cannot log into this portal. Please use the {expected}.','danger')
                return render_template('login.html', portal=portal)
            login_user(user); log_login(user)
            if user.role == 'company':     return redirect(url_for('company_dashboard'))
            if user.role == 'dataservice': return redirect(url_for('ds_dashboard'))
            return redirect(url_for('customer_home'))
        flash('Invalid email or password.','danger')
    portal = request.args.get('portal','')
    return render_template('login.html', portal=portal)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        if User.query.filter_by(email=email).first():
            flash('Email already registered.','danger'); return redirect(url_for('register'))
        user = User(name=request.form['name'],email=email,
                    password=generate_password_hash(request.form['password']),role='customer',
                    phone=request.form.get('phone',''),car_model=request.form.get('car_model',''),
                    car_year=request.form.get('car_year',''),car_reg=request.form.get('car_reg',''),
                    address=request.form.get('address',''))
        db.session.add(user); db.session.flush()
        user.customer_id = f"CUS{user.id:04d}"; db.session.commit()
        send_mail(user.email,"Welcome to AutoSpares! 🎉",
            mail_html("New Account","Hi "+user.name+",",
                f'<div style="background:#1a1e2a;border:1px solid #2d3748;border-radius:10px;padding:20px;margin:20px 0;text-align:center">'
                f'<div style="color:#9ca3af;font-size:13px;margin-bottom:8px">YOUR CUSTOMER ID</div>'
                f'<div style="font-size:32px;font-weight:900;color:#e8a020;letter-spacing:4px">{user.customer_id}</div>'
                f'<div style="color:#9ca3af;font-size:12px;margin-top:8px">Save this for all your interactions</div>'
                f'</div>'
                f'<p style="color:#9ca3af">Welcome! You can now browse parts, place orders, raise part requests and support tickets from your customer portal.</p>'),
            f"Welcome! Customer ID: {user.customer_id}")
        login_user(user); log_login(user)
        flash(f'Welcome! Your Customer ID is {user.customer_id}','success')
        return redirect(url_for('customer_home'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('index'))

@app.route('/forgot-password',methods=['GET','POST'])
def forgot_password():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form.get('email','').strip()).first()
        if user:
            user.reset_token = secrets.token_urlsafe(32); db.session.commit()
            link = url_for('reset_password',token=user.reset_token,_external=True)
            send_mail(user.email,"Reset Your AutoSpares Password 🔐",
                mail_html("Password Reset","Hi "+user.name+",",
                    '<p style="color:#9ca3af">Click the button below to reset your password. This link is valid for one use only.</p>',
                    "Reset My Password",link),
                f"Reset link: {link}")
        flash('If that email is registered, a reset link has been sent.','info')
        return redirect(url_for('login'))
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>',methods=['GET','POST'])
def reset_password(token):
    user = User.query.filter_by(reset_token=token).first()
    if not user: flash('Invalid or expired reset link.','danger'); return redirect(url_for('login'))
    if request.method == 'POST':
        pw = request.form.get('password','').strip()
        if len(pw)<6: flash('Min 6 characters.','danger'); return render_template('reset_password.html',token=token)
        user.password=generate_password_hash(pw); user.reset_token=None; db.session.commit()
        flash('Password reset! Please log in.','success'); return redirect(url_for('login'))
    return render_template('reset_password.html',token=token)

@app.route('/uploads/<filename>')
@login_required
def uploaded_file(filename): return send_from_directory(UPLOAD_FOLDER,filename)

# ── CUSTOMER ──────────────────────────────────────────────────────────────────────
@app.route('/customer/')
@login_required
def customer_home():
    if current_user.role!='customer': return redirect(url_for('login'))
    active_orders  = Order.query.filter_by(customer_id=current_user.id).filter(
        Order.status.notin_(['delivered','closed'])).order_by(Order.created_at.desc()).all()
    open_tickets   = Ticket.query.filter_by(customer_id=current_user.id,status='open').count()
    open_requests  = PartRequest.query.filter_by(customer_id=current_user.id,status='open').count()
    return render_template('customer/home.html',orders=active_orders,open_tickets=open_tickets,open_requests=open_requests)

@app.route('/customer/diagnose')
@login_required
def customer_diagnose():
    if current_user.role!='customer': return redirect(url_for('login'))
    return render_template('customer/diagnose.html')

@app.route('/customer/api/diagnose',methods=['POST'])
@login_required
def customer_api_diagnose():
    import anthropic
    data=request.json; vehicle=data.get('vehicle',f"{current_user.car_model} {current_user.car_year}"); symptoms=data.get('symptoms','')
    client=anthropic.Anthropic(api_key=get_api_key())
    resp=client.messages.create(model="claude-haiku-4-5-20251001",max_tokens=400,
        system=f"Expert auto mechanic. Inventory:\n{parts_context()}\nReply: Diagnosis | Parts Needed | Inventory Check | Severity | Drive or Tow?",
        messages=[{"role":"user","content":f"Vehicle: {vehicle}\nSymptoms: {symptoms}"}])
    return jsonify({"result":resp.content[0].text})

@app.route('/customer/parts')
@login_required
def customer_parts(): return redirect(url_for('customer_shop'))

@app.route('/customer/shop')
@login_required
def customer_shop():
    if current_user.role!='customer': return redirect(url_for('login'))
    parts=Part.query.all(); cart=session.get('cart',{})
    categories=sorted(set(p.category for p in parts if p.category))
    return render_template('customer/shop.html',parts=parts,cart=cart,categories=categories)

@app.route('/customer/cart/add/<int:part_id>',methods=['POST'])
@login_required
def cart_add(part_id):
    part=db.get_or_404(Part, part_id); qty=int(request.form.get('quantity',1))
    cart=session.get('cart',{}); key=str(part_id)
    cart[key]={'id':part_id,'name':part.name,'brand':part.brand,'price':part.price,'qty':cart.get(key,{}).get('qty',0)+qty,'stock':part.stock}
    session['cart']=cart; session.modified=True; flash(f'"{part.name}" added to cart!','success'); return redirect(url_for('customer_shop'))

@app.route('/customer/cart/remove/<int:part_id>',methods=['POST'])
@login_required
def cart_remove(part_id):
    cart=session.get('cart',{}); cart.pop(str(part_id),None)
    session['cart']=cart; session.modified=True; return redirect(url_for('customer_checkout'))

@app.route('/customer/cart/update/<int:part_id>',methods=['POST'])
@login_required
def cart_update(part_id):
    cart=session.get('cart',{}); key=str(part_id)
    if key in cart: cart[key]['qty']=max(1,int(request.form.get('quantity',1)))
    session['cart']=cart; session.modified=True; return redirect(url_for('customer_checkout'))

@app.route('/customer/checkout')
@login_required
def customer_checkout():
    if current_user.role!='customer': return redirect(url_for('login'))
    cart=session.get('cart',{}); total=sum(v['price']*v['qty'] for v in cart.values())
    return render_template('customer/checkout.html',cart=cart,total=total)

@app.route('/customer/place-order',methods=['POST'])
@login_required
def customer_place_order():
    cart=session.get('cart',{})
    if not cart: flash('Your cart is empty.','danger'); return redirect(url_for('customer_shop'))
    for key,item in cart.items():
        part=db.session.get(Part, item['id'])
        if not part or part.stock<item['qty']:
            flash(f"Insufficient stock for {item['name']}.","danger"); return redirect(url_for('customer_checkout'))
    total=sum(v['price']*v['qty'] for v in cart.values())
    items_list=[{'part_id':v['id'],'name':v['name'],'brand':v['brand'],'qty':v['qty'],'price':v['price']} for v in cart.values()]
    delivery_method=request.form.get('delivery_method','showroom')
    order=Order(customer_id=current_user.id,items_json=json.dumps(items_list),total_price=total,status='pending',delivery_method=delivery_method)
    db.session.add(order); db.session.commit(); session.pop('cart',None)
    rows=''.join(f'<tr><td style="padding:8px 12px;border-bottom:1px solid #2d3748">{i["name"]}</td><td style="padding:8px 12px;border-bottom:1px solid #2d3748;text-align:center">{i["qty"]}</td><td style="padding:8px 12px;border-bottom:1px solid #2d3748;text-align:right;color:#e8a020">₹{i["price"]*i["qty"]:.0f}</td></tr>' for i in items_list)
    send_mail(current_user.email,f"✅ Order #{order.id} Placed – AutoSpares",
        mail_html(f"Order #{order.id} Placed",f"Hi {current_user.name},",
            f'<table style="width:100%;border-collapse:collapse;background:#1a1e2a;border-radius:8px;overflow:hidden;margin:16px 0"><tr style="background:#242830"><th style="padding:10px 12px;text-align:left;color:#9ca3af;font-size:12px">PART</th><th style="padding:10px 12px;color:#9ca3af;font-size:12px">QTY</th><th style="padding:10px 12px;text-align:right;color:#9ca3af;font-size:12px">AMOUNT</th></tr>{rows}<tr><td colspan="2" style="padding:12px;font-weight:700;font-size:15px">TOTAL</td><td style="padding:12px;text-align:right;color:#e8a020;font-weight:700;font-size:18px">₹{total:.0f}</td></tr></table>'
            f'<div style="background:#1a1e2a;border-radius:8px;padding:14px;display:flex;gap:16px;flex-wrap:wrap"><div><div style="color:#9ca3af;font-size:11px">ORDER ID</div><div style="color:#e8a020;font-weight:700;font-size:18px">#{order.id}</div></div><div><div style="color:#9ca3af;font-size:11px">DELIVERY</div><div style="font-weight:600">{delivery_method.title()}</div></div></div>',
            "Track My Order",url_for('customer_track',order_id=order.id,_external=True)),
        f"Order #{order.id} placed.")
    flash(f'Order #{order.id} placed!','success'); return redirect(url_for('customer_track',order_id=order.id))

@app.route('/customer/orders')
@login_required
def customer_orders():
    if current_user.role!='customer': return redirect(url_for('login'))
    sf=request.args.get('status','active')
    all_orders=Order.query.filter_by(customer_id=current_user.id).order_by(Order.created_at.desc()).all()
    active=['pending','checking','processing','packing','received','appointment_set','out_for_delivery']
    if sf=='active':   orders=[o for o in all_orders if o.status in active]
    elif sf=='done':   orders=[o for o in all_orders if o.status in ['delivered','closed']]
    else:              orders=all_orders
    counts={'active':sum(1 for o in all_orders if o.status in active),
            'done':sum(1 for o in all_orders if o.status in ['delivered','closed']),
            'all':len(all_orders)}
    return render_template('customer/orders.html',orders=orders,status_filter=sf,counts=counts)

@app.route('/customer/track/<int:order_id>')
@login_required
def customer_track(order_id):
    order=Order.query.filter_by(id=order_id,customer_id=current_user.id).first_or_404()
    return render_template('customer/track.html',order=order,now=datetime.now())

@app.route('/customer/bill/<int:order_id>')
@login_required
def customer_bill(order_id):
    order=Order.query.filter_by(id=order_id,customer_id=current_user.id).first_or_404()
    resp=make_response(generate_bill_html(order))
    resp.headers['Content-Type']='text/html; charset=utf-8'
    return resp

@app.route('/customer/appointment/<int:order_id>',methods=['POST'])
@login_required
def customer_appointment(order_id):
    order=Order.query.filter_by(id=order_id,customer_id=current_user.id).first_or_404()
    if order.status=='received':
        dt_raw=request.form.get('appointment','')
        try:
            dt_obj=datetime.strptime(dt_raw,'%Y-%m-%dT%H:%M')
            order.appointment=dt_obj.strftime('%d %b %Y at %I:%M %p')
        except: order.appointment=dt_raw
        order.status='appointment_set'; db.session.commit()
        send_mail(current_user.email,f"📅 Appointment Confirmed – Order #{order.id}",
            mail_html("Appointment Confirmed",f"Hi {current_user.name},",
                f'<div style="background:#1a1e2a;border:2px solid #2ecc71;border-radius:10px;padding:24px;text-align:center">'
                f'<div style="font-size:44px;margin-bottom:10px">📅</div>'
                f'<div style="font-size:22px;font-weight:700;color:#2ecc71">{order.appointment}</div>'
                f'<div style="color:#9ca3af;font-size:14px;margin-top:8px">Order #{order.id} · Please arrive on time</div>'
                f'<div style="color:#9ca3af;font-size:13px;margin-top:6px">📍 Visit our showroom with this confirmation</div></div>'),
            f"Appointment: {order.appointment}")
        flash(f'Appointment confirmed for {order.appointment}!','success')
    return redirect(url_for('customer_track',order_id=order_id))

@app.route('/customer/requests/reopen/<int:req_id>',methods=['POST'])
@login_required
def customer_request_reopen(req_id):
    req=PartRequest.query.filter_by(id=req_id,customer_id=current_user.id).first_or_404()
    if req.status=='closed':
        reason=request.form.get('reason','').strip()
        req.status='open'; req.description=(req.description or '')+(f'\n\n[REOPENED] {reason}' if reason else '\n\n[REOPENED]')
        db.session.commit(); flash('Part request reopened.','success')
    return redirect(url_for('customer_request_detail',req_id=req_id))

@app.route('/customer/profile',methods=['GET','POST'])
@login_required
def customer_profile():
    if current_user.role!='customer': return redirect(url_for('login'))
    if request.method=='POST':
        for f in ['name','phone','car_model','car_year','car_reg','address']:
            setattr(current_user,f,request.form.get(f,getattr(current_user,f)))
        pw=request.form.get('new_password','').strip()
        if pw: current_user.password=generate_password_hash(pw)
        db.session.commit(); flash('Profile updated!','success')
    return render_template('customer/profile.html')

# ── PART REQUESTS (Customer) ───────────────────────────────────────────────────────
@app.route('/customer/requests')
@login_required
def customer_requests():
    if current_user.role!='customer': return redirect(url_for('login'))
    sf=request.args.get('status','open')
    q=PartRequest.query.filter_by(customer_id=current_user.id)
    if sf and sf!='all': q=q.filter_by(status=sf)
    return render_template('customer/requests.html',requests=q.order_by(PartRequest.created_at.desc()).all(),status_filter=sf)

@app.route('/customer/requests/<int:req_id>')
@login_required
def customer_request_detail(req_id):
    if current_user.role!='customer': return redirect(url_for('login'))
    req=PartRequest.query.filter_by(id=req_id,customer_id=current_user.id).first_or_404()
    return render_template('customer/request_detail.html',req=req)

@app.route('/customer/requests/new',methods=['GET','POST'])
@login_required
def customer_new_request():
    if current_user.role!='customer': return redirect(url_for('login'))
    if request.method=='POST':
        # Collect all parts from dynamic form
        part_names   = request.form.getlist('part_name[]')
        part_numbers = request.form.getlist('part_number[]')
        brand_prefs  = request.form.getlist('brand_pref[]')
        quantities   = request.form.getlist('quantity[]')

        # Filter out empty rows
        parts_data = [(n.strip(), pn.strip(), bp.strip(), int(q or 1))
                      for n, pn, bp, q in zip(part_names, part_numbers, brand_prefs, quantities)
                      if n.strip()]

        if not parts_data:
            flash('Please enter at least one part name.','danger')
            return redirect(url_for('customer_new_request'))

        att      = save_upload('attachment')
        car_model= request.form.get('car_model', current_user.car_model or '')
        car_year = request.form.get('car_year',  current_user.car_year  or '')
        car_reg  = request.form.get('car_reg',   current_user.car_reg   or '')
        urgency  = request.form.get('urgency','normal')
        description = request.form.get('description','')

        created_ids = []
        for part_name, part_number, brand_pref, qty in parts_data:
            req = PartRequest(
                customer_id=current_user.id, part_name=part_name,
                part_number=part_number, brand_pref=brand_pref,
                car_model=car_model, car_year=car_year, car_reg=car_reg,
                urgency=urgency, quantity=qty, description=description,
                attachment=att if not created_ids else None  # attachment on first only
            )
            db.session.add(req)
            db.session.flush()
            created_ids.append(req.id)

        db.session.commit()

        # Build email summary
        parts_rows = ''.join(
            f'<tr><td style="padding:8px 12px;border-bottom:1px solid #2d3748;font-size:14px">{n}</td>' +
            f'<td style="padding:8px 12px;border-bottom:1px solid #2d3748;text-align:center;font-size:14px">{q}</td>' +
            f'<td style="padding:8px 12px;border-bottom:1px solid #2d3748;font-size:14px;color:#9ca3af">{bp or "Any"}</td></tr>'
            for n,_,bp,q in parts_data
        )
        ids_str = ', '.join(f'#{i}' for i in created_ids)
        send_mail(current_user.email, f"📩 Part Request{'s' if len(created_ids)>1 else ''} {ids_str} Submitted",
            mail_html("Part Request Submitted", f"Hi {current_user.name},",
                f'<p>Your request for <strong>{len(created_ids)}</strong> part(s) has been submitted.</p>'
                f'<table style="width:100%;border-collapse:collapse;background:#1a1e2a;border-radius:8px;overflow:hidden;margin:16px 0">'
                f'<tr style="background:#242830"><th style="padding:8px 12px;text-align:left;color:#9ca3af;font-size:12px">PART</th><th style="padding:8px 12px;color:#9ca3af;font-size:12px">QTY</th><th style="padding:8px 12px;text-align:left;color:#9ca3af;font-size:12px">BRAND PREF</th></tr>'
                f'{parts_rows}'
                f'</table>'
                f'<div style="background:#1a1e2a;border-radius:8px;padding:14px"><div style="color:#9ca3af;font-size:12px">URGENCY</div><div style="font-weight:700;color:{"#e84040" if urgency=="urgent" else "#e8a020"}">{urgency.title()}</div></div>',
                "View My Requests", url_for('customer_requests', _external=True)),
            f"Requests submitted: {', '.join(n for n,*_ in parts_data)}")

        if len(created_ids) == 1:
            flash(f'Part request #{created_ids[0]} submitted!', 'success')
            return redirect(url_for('customer_request_detail', req_id=created_ids[0]))
        else:
            flash(f'{len(created_ids)} part requests submitted!', 'success')
            return redirect(url_for('customer_requests'))

    # GET — pre-fill from query params (e.g. from shop "Request This Part")
    prefill_part  = request.args.get('part', '')
    prefill_brand = request.args.get('brand', '')
    return render_template('customer/new_request.html', prefill_part=prefill_part, prefill_brand=prefill_brand)

# ── TICKETS (Customer) ─────────────────────────────────────────────────────────────
@app.route('/customer/tickets')
@login_required
def customer_tickets():
    if current_user.role!='customer': return redirect(url_for('login'))
    sf=request.args.get('status','open'); catf=request.args.get('category','')
    q=Ticket.query.filter_by(customer_id=current_user.id)
    if sf and sf!='all': q=q.filter_by(status=sf)
    if catf: q=q.filter_by(category=catf)
    counts={'open':Ticket.query.filter_by(customer_id=current_user.id,status='open').count(),
            'replied':Ticket.query.filter_by(customer_id=current_user.id,status='replied').count(),
            'closed':Ticket.query.filter_by(customer_id=current_user.id,status='closed').count()}
    return render_template('customer/tickets.html',tickets=q.order_by(Ticket.created_at.desc()).all(),
        status_filter=sf,category_filter=catf,categories=Ticket.CATEGORY_LABELS,counts=counts)

@app.route('/customer/tickets/<int:ticket_id>')
@login_required
def customer_ticket_detail(ticket_id):
    if current_user.role!='customer': return redirect(url_for('login'))
    ticket=Ticket.query.filter_by(id=ticket_id,customer_id=current_user.id).first_or_404()
    return render_template('customer/ticket_detail.html',ticket=ticket)

@app.route('/customer/tickets/<int:ticket_id>/reopen',methods=['POST'])
@login_required
def customer_ticket_reopen(ticket_id):
    ticket=Ticket.query.filter_by(id=ticket_id,customer_id=current_user.id).first_or_404()
    if ticket.status=='closed':
        reason=request.form.get('reason','').strip()
        if not reason: flash('Please provide a reason for reopening.','danger'); return redirect(url_for('customer_ticket_detail',ticket_id=ticket_id))
        ticket.status='open'; ticket.reopen_reason=reason; db.session.commit()
        flash('Ticket reopened. Our team will review it again.','success')
    return redirect(url_for('customer_ticket_detail',ticket_id=ticket_id))

@app.route('/customer/tickets/new',methods=['GET','POST'])
@login_required
def customer_new_ticket():
    if current_user.role!='customer': return redirect(url_for('login'))
    orders=Order.query.filter_by(customer_id=current_user.id).all()
    if request.method=='POST':
        att=save_upload('attachment')
        ticket=Ticket(customer_id=current_user.id,order_id=request.form.get('order_id') or None,
            category=request.form.get('category','general'),subject=request.form['subject'],
            message=request.form['message'],priority=request.form.get('priority','normal'),attachment=att)
        db.session.add(ticket); db.session.commit()
        send_mail(current_user.email,f"🎫 Ticket #{ticket.id} Raised",
            mail_html("Support Ticket Raised",f"Hi {current_user.name},",
                f'<div style="background:#1a1e2a;border-radius:10px;padding:20px;margin:16px 0"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px"><div><div style="color:#9ca3af;font-size:12px">TICKET ID</div><div style="font-weight:700;color:#e8a020;font-size:18px">#{ticket.id}</div></div><div><div style="color:#9ca3af;font-size:12px">CATEGORY</div><div style="font-weight:700">{ticket.category_label()}</div></div><div><div style="color:#9ca3af;font-size:12px">PRIORITY</div><div style="font-weight:700;color:{"#e84040" if ticket.priority=="high" else "#e8a020"}">{ticket.priority.title()}</div></div></div><div style="margin-top:14px;padding-top:14px;border-top:1px solid #2d3748"><div style="color:#9ca3af;font-size:12px">SUBJECT</div><div style="font-weight:600;font-size:15px">{ticket.subject}</div></div></div>',
                "View Ticket",url_for('customer_ticket_detail',ticket_id=ticket.id,_external=True)),
            f"Ticket #{ticket.id}: {ticket.subject}")
        flash(f'Ticket #{ticket.id} raised!','success'); return redirect(url_for('customer_ticket_detail',ticket_id=ticket.id))
    return render_template('customer/new_ticket.html',orders=orders,categories=Ticket.CATEGORY_LABELS)

# ── COMPANY ────────────────────────────────────────────────────────────────────────
@app.route('/company/')
@login_required
def company_dashboard():
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/dashboard.html',
        total_parts=Part.query.count(),low_stock=Part.query.filter(Part.stock>0,Part.stock<=3).count(),
        out_of_stock=Part.query.filter(Part.stock==0).count(),
        pending_orders=Order.query.filter_by(status='pending').count(),
        open_requests=PartRequest.query.filter_by(status='open').count(),
        open_tickets=Ticket.query.filter_by(status='open').count(),
        recent_orders=Order.query.order_by(Order.created_at.desc()).limit(5).all(),
        total_customers=User.query.filter_by(role='customer').count())

@app.route('/company/chatbot')
@login_required
def company_chatbot():
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/chatbot.html')

@app.route('/company/api/chat',methods=['POST'])
@login_required
def company_api_chat():
    import anthropic
    messages=request.json.get('messages',[])
    client=anthropic.Anthropic(api_key=get_api_key())
    resp=client.messages.create(model="claude-haiku-4-5-20251001",max_tokens=400,
        system=f"Spare parts assistant for Indian auto store.\nInventory:\n{parts_context()}",messages=messages)
    return jsonify({"reply":resp.content[0].text})

@app.route('/company/inventory')
@login_required
def company_inventory():
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/inventory.html',parts=Part.query.all())

@app.route('/company/inventory/edit/<int:part_id>',methods=['POST'])
@login_required
def company_edit_part(part_id):
    part = db.get_or_404(Part, part_id)
    # Accept both JSON (from fetch) and form data
    if request.is_json:
        data = request.get_json()
    else:
        data = request.form
    part.name       = data.get('name',       part.name)
    part.brand      = data.get('brand',      part.brand)
    part.category   = data.get('category',   part.category)
    part.compatible = data.get('compatible', part.compatible)
    try: part.price = float(data.get('price', part.price))
    except: pass
    try: part.stock = int(data.get('stock', part.stock))
    except: pass
    db.session.commit()
    return jsonify({"ok": True, "name": part.name, "stock": part.stock, "price": part.price})

@app.route('/company/inventory/add-page')
@login_required
def company_add_part_page():
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/add_part.html')

@app.route('/company/inventory/add',methods=['POST'])
@login_required
def company_add_part():
    db.session.add(Part(name=request.form['name'],brand=request.form['brand'],category=request.form['category'],
        price=float(request.form['price']),stock=int(request.form['stock']),compatible=request.form['compatible']))
    db.session.commit(); flash('Part added!','success'); return redirect(url_for('company_add_part_page'))

@app.route('/company/report')
@login_required
def company_report():
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/report.html')

@app.route('/company/api/report',methods=['POST'])
@login_required
def company_api_report():
    import anthropic
    client=anthropic.Anthropic(api_key=get_api_key())
    resp=client.messages.create(model="claude-haiku-4-5-20251001",max_tokens=500,
        system="Inventory analyst for Indian auto parts store. Cover: health summary, low/out alerts, top 3 by value, category breakdown, reorder suggestions, one tip.",
        messages=[{"role":"user","content":f"Inventory:\n{parts_context()}"}])
    return jsonify({"report":resp.content[0].text})

# ── COMPANY: Orders ────────────────────────────────────────────────────────────────
@app.route('/company/orders')
@login_required
def company_orders():
    if current_user.role!='company': return redirect(url_for('login'))
    sf=request.args.get('status','all')
    all_orders=Order.query.order_by(Order.created_at.desc()).all()
    active_statuses=['pending','checking','processing','packing','received','appointment_set','out_for_delivery']
    if sf=='active':   orders=[o for o in all_orders if o.status in active_statuses]
    elif sf=='done':   orders=[o for o in all_orders if o.status in ['delivered','closed']]
    elif sf=='all':    orders=all_orders
    else:              orders=[o for o in all_orders if o.status==sf]
    counts={s:Order.query.filter_by(status=s).count() for s in ['pending','checking','processing','packing','received','appointment_set','out_for_delivery','delivered','closed']}
    counts['active']=sum(counts[s] for s in active_statuses)
    counts['done']=counts['delivered']+counts['closed']
    counts['all']=len(all_orders)
    return render_template('company/orders.html',orders=orders,status_filter=sf,counts=counts)

@app.route('/company/orders/<int:order_id>')
@login_required
def company_order_detail(order_id):
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/order_detail.html',order=db.get_or_404(Order, order_id),now=datetime.now())


@app.route("/company/orders/<int:order_id>/received",methods=["POST"])
@login_required
def company_order_received_compat(order_id):
    return company_order_ready(order_id)
@app.route('/company/orders/<int:order_id>/check',methods=['POST'])
@login_required
def company_order_check(order_id):
    order=db.get_or_404(Order, order_id)
    if request.form.get('action')=='approve':
        order.status='checking'; db.session.commit()
        send_mail(order.customer.email,f"🔍 Order #{order.id} Under Review",
            mail_html(f"Order #{order.id} Update",f"Hi {order.customer.name},",f'<p>Your order is now <strong style="color:#3a8fd4">Under Review</strong>. We will confirm shortly.</p>'),
            "Under review"); flash('Moved to Checking.','success')
    else:
        order.status='closed'; order.close_reason=request.form.get('reason','Rejected.'); db.session.commit()
        send_mail(order.customer.email,f"❌ Order #{order.id} Closed",
            mail_html(f"Order #{order.id} Closed",f"Hi {order.customer.name},",f'<p>Your order was closed.</p><div style="background:#1a1e2a;padding:14px;border-radius:8px;border-left:3px solid #e84040"><strong>Reason:</strong> {order.close_reason}</div>'),
            f"Closed: {order.close_reason}"); flash('Order closed.','warning')
    return redirect(url_for('company_order_detail',order_id=order_id))

@app.route('/company/orders/<int:order_id>/process',methods=['POST'])
@login_required
def company_order_process(order_id):
    order=db.get_or_404(Order, order_id)
    if order.status=='checking':
        order.status='processing'; order.deadline=request.form.get('deadline',''); order.notes=request.form.get('notes','')
        db.session.commit()
        send_mail(order.customer.email,f"⚙️ Order #{order.id} Confirmed",
            mail_html(f"Order Confirmed",f"Hi {order.customer.name},",f'<p>Your order is confirmed and being processed! Expected by: <strong style="color:#e8a020">{order.deadline}</strong></p>'),
            f"ETA: {order.deadline}"); flash('Processing started.','success')
    return redirect(url_for('company_order_detail',order_id=order_id))

@app.route('/company/orders/<int:order_id>/pack',methods=['POST'])
@login_required
def company_order_pack(order_id):
    order=db.get_or_404(Order, order_id)
    if order.status=='processing':
        order.status='packing'; db.session.commit()
        send_mail(order.customer.email,f"📦 Order #{order.id} Being Packed",
            mail_html("Order Packing",f"Hi {order.customer.name},",f'<p>Great news! Your order #{order.id} is now being packed and will be ready soon.</p>'),
            "Order packing"); flash('Order marked as Packing.','success')
    return redirect(url_for('company_order_detail',order_id=order_id))

@app.route('/company/orders/<int:order_id>/ready',methods=['POST'])
@login_required
def company_order_ready(order_id):
    order=db.get_or_404(Order, order_id)
    if order.status in ['packing','processing']:
        order.status='received'; db.session.commit()
        msg = 'Parts ready! Please log in to book your appointment.' if order.delivery_method=='showroom' else 'Parts ready and will be dispatched soon.'
        send_mail(order.customer.email,f"✅ Order #{order.id} Ready",
            mail_html("Parts Ready!",f"Hi {order.customer.name},",f'<div style="background:#1a1e2a;border:2px solid #2ecc71;border-radius:10px;padding:24px;text-align:center"><div style="font-size:44px">✅</div><div style="font-size:18px;font-weight:700;color:#2ecc71;margin-top:10px">Order Ready!</div><div style="color:#9ca3af;font-size:14px;margin-top:8px">{msg}</div></div>',
                "View Order",url_for('customer_track',order_id=order.id,_external=True)),
            msg); flash('Order marked as Ready.','success')
    return redirect(url_for('company_order_detail',order_id=order_id))

@app.route('/company/orders/<int:order_id>/ship',methods=['POST'])
@login_required
def company_order_ship(order_id):
    order=db.get_or_404(Order, order_id)
    if order.status in ['received','packing','processing']:
        order.courier_name=request.form.get('courier_name',''); order.tracking_id=request.form.get('tracking_id','')
        order.status='out_for_delivery'; db.session.commit()
        send_mail(order.customer.email,f"🚚 Order #{order.id} Shipped!",
            mail_html("Order Shipped!",f"Hi {order.customer.name},",
                f'<div style="background:#1a1e2a;border:2px solid #3a8fd4;border-radius:10px;padding:24px;text-align:center"><div style="font-size:44px">🚚</div><div style="font-size:18px;font-weight:700;color:#3a8fd4;margin-top:10px">Your Order Is On The Way!</div></div>'
                f'<div style="background:#1a1e2a;border-radius:8px;padding:16px;margin-top:16px"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px"><div><div style="color:#9ca3af;font-size:12px">COURIER</div><div style="font-weight:700">{order.courier_name}</div></div><div><div style="color:#9ca3af;font-size:12px">TRACKING ID</div><div style="font-weight:700;color:#e8a020;font-family:monospace;font-size:16px">{order.tracking_id}</div></div></div></div>'
                f'<div style="margin-top:16px;padding:14px;background:rgba(232,160,32,.1);border:1px solid rgba(232,160,32,.3);border-radius:8px;font-size:13px;color:#9ca3af">⚠️ Once handed to our courier partner, AutoSpares is not responsible for any damage, delay, or loss during transit. Please check the package upon delivery before signing.</div>'),
            f"Shipped via {order.courier_name}, tracking: {order.tracking_id}")
        flash(f'Order shipped via {order.courier_name}!','success')
    return redirect(url_for('company_order_detail',order_id=order_id))

@app.route('/company/orders/<int:order_id>/deliver',methods=['POST'])
@login_required
def company_order_deliver(order_id):
    order=db.get_or_404(Order, order_id)
    if order.status in ['appointment_set','out_for_delivery','received']:
        order.status='delivered'; db.session.commit()
        send_mail(order.customer.email,f"🎉 Order #{order.id} Delivered!",
            mail_html("Order Delivered!",f"Hi {order.customer.name},",
                f'<div style="background:#1a1e2a;border:2px solid #2ecc71;border-radius:10px;padding:28px;text-align:center"><div style="font-size:48px">🎉</div><div style="font-size:20px;font-weight:700;color:#2ecc71;margin-top:10px">Order Delivered!</div><div style="color:#9ca3af;font-size:14px;margin-top:8px">Thank you for choosing AutoSpares. We hope to serve you again!</div></div>'
                f'<div style="margin-top:16px;text-align:center"><a href="{url_for("customer_bill",order_id=order.id,_external=True)}" style="background:#e8a020;color:#000;padding:12px 28px;border-radius:8px;font-weight:700;text-decoration:none;font-size:15px">📄 Download Invoice</a></div>'),
            "Order delivered!")
        flash('Order marked as Delivered!','success')
    return redirect(url_for('company_order_detail',order_id=order_id))


@app.route('/company/bill/<int:order_id>')
@login_required
def company_bill(order_id):
    if current_user.role!='company': return redirect(url_for('login'))
    order=db.get_or_404(Order, order_id)
    resp=make_response(generate_bill_html(order))
    resp.headers['Content-Type']='text/html; charset=utf-8'
    return resp

# ── COMPANY: Part Requests ─────────────────────────────────────────────────────────
@app.route('/company/requests')
@login_required
def company_requests():
    if current_user.role!='company': return redirect(url_for('login'))
    sf=request.args.get('status','open'); uf=request.args.get('urgency','')
    q=PartRequest.query.order_by(PartRequest.created_at.desc())
    if sf and sf!='all': q=q.filter_by(status=sf)
    if uf: q=q.filter_by(urgency=uf)
    counts={'open':PartRequest.query.filter_by(status='open').count(),'acknowledged':PartRequest.query.filter_by(status='acknowledged').count(),
            'sourcing':PartRequest.query.filter_by(status='sourcing').count(),'closed':PartRequest.query.filter_by(status='closed').count()}
    return render_template('company/requests.html',requests=q.all(),status_filter=sf,urgency_filter=uf,counts=counts)

@app.route('/company/requests/<int:req_id>')
@login_required
def company_request_detail(req_id):
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/request_detail.html',req=db.get_or_404(PartRequest, req_id))

@app.route('/company/requests/<int:req_id>/reply',methods=['POST'])
@login_required
def company_request_reply(req_id):
    req=db.get_or_404(PartRequest, req_id)
    req.admin_reply=request.form.get('reply',''); req.status=request.form.get('status','acknowledged')
    att=save_upload('admin_attachment')
    if att: req.admin_attachment=att
    est=request.form.get('estimated_price','').strip()
    if est:
        try: req.estimated_price=float(est)
        except: pass
    db.session.commit()
    price_str=f'<div style="margin-top:14px;padding:14px;background:#1a1e2a;border-radius:8px;border-left:3px solid #e8a020"><div style="color:#9ca3af;font-size:12px">ESTIMATED PRICE</div><div style="font-size:22px;font-weight:700;color:#e8a020">₹{req.estimated_price:.0f}</div></div>' if req.estimated_price else ''
    send_mail(req.customer.email,f"📩 Update on Part Request #{req.id}",
        mail_html(f"Request #{req.id} Update",f"Hi {req.customer.name},",
            f'<div style="background:#1a1e2a;border-radius:10px;padding:16px;margin-bottom:16px"><div style="color:#9ca3af;font-size:12px">REGARDING</div><div style="font-weight:700;font-size:16px">{req.part_name}</div><div style="color:#e8a020;font-size:13px;margin-top:6px">{req.status.title()}</div></div>'
            f'<div style="padding:16px;background:#1a1e2a;border-radius:8px;border-left:3px solid #3a8fd4;font-size:15px">{req.admin_reply}</div>{price_str}',
            "View Request",url_for('customer_request_detail',req_id=req.id,_external=True)),
        req.admin_reply)
    flash('Reply sent.','success'); return redirect(url_for('company_request_detail',req_id=req_id))


@app.route('/company/requests/<int:req_id>/convert-to-order', methods=['POST'])
@login_required
def company_request_convert(req_id):
    """Add requested part to inventory (if qty given) and create an order for the customer."""
    if current_user.role != 'company': return redirect(url_for('login'))
    req = db.get_or_404(PartRequest, req_id)

    # Optionally add part to inventory
    add_to_inv = request.form.get('add_to_inventory') == '1'
    price = float(request.form.get('price', 0) or 0)
    stock = int(request.form.get('stock', 1) or 1)

    if add_to_inv and price > 0:
        part = Part(
            name=req.part_name,
            brand=req.brand_pref or 'N/A',
            category='Requested',
            price=price,
            stock=stock,
            compatible=f"{req.car_model or ''} {req.car_year or ''}".strip()
        )
        db.session.add(part)
        db.session.flush()
        part_id = part.id
        part_price = price
        part_name = part.name
        part_brand = part.brand
    else:
        # Use price from request estimate, don't add to inventory
        part_id = None
        part_price = req.estimated_price or price or 0
        part_name = req.part_name
        part_brand = req.brand_pref or ''

    qty = int(request.form.get('quantity', req.quantity or 1))
    total = part_price * qty
    delivery_method = request.form.get('delivery_method', 'showroom')
    items_list = [{'part_id': part_id, 'name': part_name, 'brand': part_brand, 'qty': qty, 'price': part_price}]

    order = Order(
        customer_id=req.customer_id,
        items_json=json.dumps(items_list),
        total_price=total,
        status='checking',
        delivery_method=delivery_method,
        notes=f'[FROM PART REQUEST #{req.id}]'
    )
    db.session.add(order)
    req.status = 'closed'
    db.session.commit()

    send_mail(req.customer.email, f"Order #{order.id} Created for Your Request – AutoSpares",
        mail_html(f"Order #{order.id} Ready",f"Hi {req.customer.name},",
            f'<p>Great news! We have sourced <strong>{part_name}</strong> as requested and created an order for you.</p>'
            f'<div style="background:#1a1e2a;border-radius:10px;padding:16px;margin:16px 0">'
            f'<div style="color:#9ca3af;font-size:12px">ORDER ID</div>'
            f'<div style="font-size:22px;font-weight:700;color:#e8a020">#{order.id}</div>'
            f'<div style="margin-top:8px;color:#9ca3af;font-size:13px">{part_name} &times; {qty}</div>'
            f'<div style="font-size:18px;font-weight:700;color:#e8a020;margin-top:4px">Total: &#8377;{total:.0f}</div></div>'
            f'<p style="color:#9ca3af">Your request has been fulfilled. Track your order from the customer portal.</p>',
            "Track My Order", url_for('customer_track', order_id=order.id, _external=True)),
        f"Order #{order.id} created for your request: {part_name}")

    flash(f'Order #{order.id} created for {req.customer.name}! Part request closed.', 'success')
    return redirect(url_for('company_order_detail', order_id=order.id))

# ── COMPANY: Tickets ───────────────────────────────────────────────────────────────
@app.route('/company/tickets')
@login_required
def company_tickets():
    if current_user.role!='company': return redirect(url_for('login'))
    sf=request.args.get('status','open'); pf=request.args.get('priority',''); catf=request.args.get('category','')
    q=Ticket.query.order_by(Ticket.created_at.desc())
    if sf and sf!='all': q=q.filter_by(status=sf)
    if pf: q=q.filter_by(priority=pf)
    if catf: q=q.filter_by(category=catf)
    counts={'open':Ticket.query.filter_by(status='open').count(),'replied':Ticket.query.filter_by(status='replied').count(),'closed':Ticket.query.filter_by(status='closed').count()}
    cat_counts={k:Ticket.query.filter_by(category=k).count() for k in Ticket.CATEGORY_LABELS}
    return render_template('company/tickets.html',tickets=q.all(),status_filter=sf,priority_filter=pf,category_filter=catf,categories=Ticket.CATEGORY_LABELS,counts=counts,cat_counts=cat_counts)

@app.route('/company/tickets/<int:ticket_id>')
@login_required
def company_ticket_detail(ticket_id):
    if current_user.role!='company': return redirect(url_for('login'))
    return render_template('company/ticket_detail.html',ticket=db.get_or_404(Ticket, ticket_id))

@app.route('/company/tickets/<int:ticket_id>/reply',methods=['POST'])
@login_required
def company_ticket_reply(ticket_id):
    ticket=db.get_or_404(Ticket, ticket_id)
    ticket.admin_reply=request.form.get('reply',''); ticket.status=request.form.get('status','replied')
    db.session.commit()
    send_mail(ticket.customer.email,f"🎫 Reply to Ticket #{ticket.id}",
        mail_html(f"Ticket #{ticket.id} Update",f"Hi {ticket.customer.name},",
            f'<div style="background:#1a1e2a;border-radius:10px;padding:14px;margin-bottom:14px"><div style="color:#9ca3af;font-size:12px">SUBJECT</div><div style="font-weight:600;font-size:15px">{ticket.subject}</div></div>'
            f'<div style="padding:16px;background:#1a1e2a;border-radius:8px;border-left:3px solid #2ecc71"><div style="color:#2ecc71;font-size:12px;font-weight:700;margin-bottom:6px">AUTOSPARES REPLY</div><div style="font-size:15px">{ticket.admin_reply}</div></div>'
            f'<div style="margin-top:12px;color:#9ca3af;font-size:13px">Status: <strong style="color:#e8a020">{ticket.status.title()}</strong></div>',
            "View Ticket",url_for('customer_ticket_detail',ticket_id=ticket.id,_external=True)),
        ticket.admin_reply)
    flash('Reply sent.','success'); return redirect(url_for('company_ticket_detail',ticket_id=ticket_id))

# ── COMPANY: Customers ─────────────────────────────────────────────────────────────
@app.route('/company/customers')
@login_required
def company_customers():
    if current_user.role!='company': return redirect(url_for('login'))
    customers=User.query.filter_by(role='customer').order_by(User.created_at.desc()).all()
    return render_template('company/customers.html',customers=customers)

@app.route('/company/customers/<int:user_id>')
@login_required
def company_customer_detail(user_id):
    if current_user.role!='company': return redirect(url_for('login'))
    customer=db.get_or_404(User, user_id)
    orders=Order.query.filter_by(customer_id=user_id).order_by(Order.created_at.desc()).all()
    tickets=Ticket.query.filter_by(customer_id=user_id).order_by(Ticket.created_at.desc()).all()
    reqs=PartRequest.query.filter_by(customer_id=user_id).order_by(PartRequest.created_at.desc()).all()
    return render_template('company/customer_detail.html',customer=customer,orders=orders,tickets=tickets,requests=reqs,parts=Part.query.all())

@app.route('/company/customers/<int:user_id>/place-order',methods=['POST'])
@login_required
def company_place_order_for_customer(user_id):
    if current_user.role!='company': return redirect(url_for('login'))
    customer=db.get_or_404(User, user_id)
    # Collect selected parts and quantities from form
    items_list = []
    total = 0.0
    parts_all = Part.query.all()
    for part in parts_all:
        qty_key = f'qty_{part.id}'
        qty = int(request.form.get(qty_key, 0))
        if qty > 0:
            if part.stock < qty:
                flash(f"Insufficient stock for {part.name} (only {part.stock} available).","danger")
                return redirect(url_for('company_customer_detail',user_id=user_id))
            items_list.append({'part_id':part.id,'name':part.name,'brand':part.brand or '','qty':qty,'price':part.price})
            total += part.price * qty
    if not items_list:
        flash('Please select at least one part.','danger')
        return redirect(url_for('company_customer_detail',user_id=user_id))
    delivery_method = request.form.get('delivery_method','showroom')
    notes = request.form.get('notes','')
    order=Order(customer_id=customer.id,items_json=json.dumps(items_list),total_price=total,
                status='checking',delivery_method=delivery_method,notes=f'[ADMIN ORDER] {notes}'.strip())
    db.session.add(order); db.session.commit()
    items_str=', '.join(f"{i['name']} x{i['qty']}" for i in items_list)
    send_mail(customer.email,f"Order #{order.id} Created for You – AutoSpares",
        mail_html(f"Order #{order.id} Created",f"Hi {customer.name},",
            f'<p>Our team has created an order on your behalf.</p>'
            f'<div style="background:#1a1e2a;border-radius:10px;padding:16px;margin:16px 0">'
            f'<div style="color:#9ca3af;font-size:12px">ORDER ID</div>'
            f'<div style="font-size:22px;font-weight:700;color:#e8a020">#{order.id}</div>'
            f'<div style="margin-top:10px;font-size:14px;color:#9ca3af">Items: {items_str}</div>'
            f'<div style="font-size:18px;font-weight:700;color:#e8a020;margin-top:6px">Total: &#8377;{total:.0f}</div></div>'
            f'<p style="color:#9ca3af">Your order is already under review. We will update you on the progress.</p>',
            "Track My Order",url_for('customer_track',order_id=order.id,_external=True)),
        f"Order #{order.id} placed for you: {items_str}")
    flash(f'Order #{order.id} placed for {customer.name} – ₹{total:.0f}. Customer notified by email.','success')
    return redirect(url_for('company_order_detail',order_id=order.id))

# ── COMPANY: Admins ────────────────────────────────────────────────────────────────
@app.route('/company/admins')
@login_required
def company_admins():
    if current_user.role!='company': return redirect(url_for('login'))
    admins=User.query.filter_by(role='company').order_by(User.created_at.desc()).all()
    return render_template('company/admins.html',admins=admins)

@app.route('/company/admins/create',methods=['POST'])
@login_required
def company_create_admin():
    if current_user.role!='company': return redirect(url_for('login'))
    email=request.form.get('email','').strip(); name=request.form.get('name','').strip(); pw=request.form.get('password','').strip()
    if not all([email,name,pw]): flash('All fields required.','danger'); return redirect(url_for('company_admins'))
    if User.query.filter_by(email=email).first(): flash('Email in use.','danger'); return redirect(url_for('company_admins'))
    admin=User(name=name,email=email,password=generate_password_hash(pw),role='company')
    db.session.add(admin); db.session.commit()
    send_mail(email,"Your AutoSpares Admin Account 🔑",
        mail_html("Admin Account Created",f"Hi {name},",
            f'<div style="background:#1a1e2a;border-radius:10px;padding:20px"><div style="margin-bottom:12px"><div style="color:#9ca3af;font-size:12px">EMAIL</div><div style="font-weight:600;font-size:15px">{email}</div></div><div><div style="color:#9ca3af;font-size:12px">TEMPORARY PASSWORD</div><div style="font-family:monospace;font-size:20px;font-weight:700;color:#e8a020;letter-spacing:2px">{pw}</div></div></div><p style="color:#9ca3af;font-size:13px">Please change your password after first login.</p>',
            "Login Now","http://localhost:5000/login"),
        f"Account: {email} / {pw}")
    flash(f'Admin created for {name}.','success'); return redirect(url_for('company_admins'))

@app.route('/company/admins/<int:admin_id>/delete',methods=['POST'])
@login_required
def company_delete_admin(admin_id):
    if current_user.role!='company': return redirect(url_for('login'))
    admin=db.get_or_404(User, admin_id)
    if admin.id==current_user.id: flash("Can't delete yourself.",'danger'); return redirect(url_for('company_admins'))
    db.session.delete(admin); db.session.commit(); flash('Admin deleted.','warning'); return redirect(url_for('company_admins'))

# ── COMPANY: Settings ──────────────────────────────────────────────────────────────
@app.route('/dataservice/settings',methods=['GET','POST'])
@login_required
def ds_settings():
    if current_user.role!='dataservice': return redirect(url_for('login'))
    mail_cfg=load_mail_cfg(); api_cfg=load_api_cfg()
    if request.method=='POST':
        action=request.form.get('action','')
        if action=='save_mail':
            u=request.form.get('mail_username','').strip(); p=request.form.get('mail_password','').strip()
            if not p and mail_cfg.get('password'): p=mail_cfg['password']
            save_mail_cfg(u,p,True); app.config['MAIL_USERNAME']=u; app.config['MAIL_PASSWORD']=p; app.config['MAIL_DEFAULT_SENDER']=u
            flash('Mail settings saved.','success')
        elif action=='disable_mail': save_mail_cfg(mail_cfg.get('username',''),mail_cfg.get('password',''),False); flash('Mail paused.','warning')
        elif action=='enable_mail':  save_mail_cfg(mail_cfg.get('username',''),mail_cfg.get('password',''),True);  flash('Mail enabled.','success')
        elif action=='clear_mail':   save_mail_cfg('','',False); flash('Mail cleared.','warning')
        elif action=='save_api':
            key=request.form.get('api_key','').strip()
            save_api_cfg(key); flash('API key saved permanently.','success')
        mail_cfg=load_mail_cfg(); api_cfg=load_api_cfg()
    return render_template('dataservice/settings.html',mail_cfg=mail_cfg,api_cfg=api_cfg)

# keep old mail-settings URL working
@app.route('/company/mail-settings',methods=['GET','POST'])
@login_required
def company_mail_settings(): return redirect(url_for('ds_settings'))

@app.route('/company/settings',methods=['GET','POST'])
@login_required
def company_settings(): return redirect(url_for('ds_settings'))

# ── DATA SERVICE ───────────────────────────────────────────────────────────────────
def ds_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args,**kwargs):
        if not current_user.is_authenticated or current_user.role!='dataservice':
            return redirect(url_for('login'))
        return f(*args,**kwargs)
    return decorated

@app.route('/dataservice/')
@login_required
@ds_required
def ds_dashboard():
    customers=User.query.filter_by(role='customer').order_by(User.created_at.desc()).all()
    total_orders=Order.query.count(); total_requests=PartRequest.query.count(); total_tickets=Ticket.query.count()
    login_logs=LoginLog.query.order_by(LoginLog.login_time.desc()).limit(100).all()
    audit_logs=[]
    if os.path.exists(DS_AUDIT):
        try:
            with open(DS_AUDIT) as f: audit_logs=json.load(f)
        except: pass
    return render_template('dataservice/dashboard.html',customers=customers,
        total_orders=total_orders,total_requests=total_requests,total_tickets=total_tickets,
        login_logs=login_logs,audit_logs=audit_logs)

@app.route('/dataservice/customers/<int:user_id>')
@login_required
@ds_required
def ds_customer_detail(user_id):
    customer=db.get_or_404(User, user_id)
    orders=Order.query.filter_by(customer_id=user_id).order_by(Order.created_at.desc()).all()
    tickets=Ticket.query.filter_by(customer_id=user_id).order_by(Ticket.created_at.desc()).all()
    reqs=PartRequest.query.filter_by(customer_id=user_id).order_by(PartRequest.created_at.desc()).all()
    return render_template('dataservice/customer_detail.html',customer=customer,orders=orders,tickets=tickets,requests=reqs)

@app.route('/dataservice/customers/<int:user_id>/edit',methods=['POST'])
@login_required
@ds_required
def ds_edit_customer(user_id):
    customer=db.get_or_404(User, user_id)
    reason=request.form.get('reason','').strip()
    if not reason: flash('Reason is required for any edit.','danger'); return redirect(url_for('ds_customer_detail',user_id=user_id))
    for f in ['name','phone','car_model','car_year','car_reg','address','email']:
        val=request.form.get(f,'').strip()
        if val: setattr(customer,f,val)
    db.session.commit()
    log_ds_audit('EDIT',f"{customer.name} ({customer.customer_id})",reason,current_user.name)
    flash('Customer info updated.','success'); return redirect(url_for('ds_customer_detail',user_id=user_id))

@app.route('/dataservice/customers/<int:user_id>/reset-password',methods=['POST'])
@login_required
@ds_required
def ds_reset_password(user_id):
    customer=db.get_or_404(User, user_id)
    reason=request.form.get('reason','').strip(); new_pw=request.form.get('new_password','').strip()
    if not reason: flash('Reason is required.','danger'); return redirect(url_for('ds_customer_detail',user_id=user_id))
    if len(new_pw)<6: flash('Password must be at least 6 characters.','danger'); return redirect(url_for('ds_customer_detail',user_id=user_id))
    customer.password=generate_password_hash(new_pw); db.session.commit()
    log_ds_audit('RESET PASSWORD',f"{customer.name} ({customer.customer_id})",reason,current_user.name)
    send_mail(customer.email,"Your AutoSpares Password Was Reset",
        mail_html("Password Reset by Admin","Hi "+customer.name+",",
            f'<p>Your password has been reset by our team.</p><div style="background:#1a1e2a;border-radius:8px;padding:16px"><div style="color:#9ca3af;font-size:12px">NEW PASSWORD</div><div style="font-family:monospace;font-size:20px;font-weight:700;color:#e8a020">{new_pw}</div></div><p style="color:#9ca3af;font-size:13px">Please log in and change your password immediately.</p>'),
        f"New password: {new_pw}")
    flash('Password reset and customer notified.','success'); return redirect(url_for('ds_customer_detail',user_id=user_id))

@app.route('/dataservice/customers/<int:user_id>/remove',methods=['POST'])
@login_required
@ds_required
def ds_remove_customer(user_id):
    customer=db.get_or_404(User, user_id)
    reason=request.form.get('reason','').strip()
    if not reason: flash('Reason is required for removing a customer.','danger'); return redirect(url_for('ds_customer_detail',user_id=user_id))
    name=customer.name; cid=customer.customer_id
    # Delete related data
    Ticket.query.filter_by(customer_id=user_id).delete()
    PartRequest.query.filter_by(customer_id=user_id).delete()
    Order.query.filter_by(customer_id=user_id).delete()
    LoginLog.query.filter_by(user_id=user_id).delete()
    db.session.delete(customer); db.session.commit()
    log_ds_audit('REMOVE CUSTOMER',f"{name} ({cid})",reason,current_user.name)
    flash(f'Customer {name} removed.','warning'); return redirect(url_for('ds_dashboard'))

@app.route('/dataservice/create-account',methods=['POST'])
@login_required
@ds_required
def ds_create_account():
    role=request.form.get('role','customer'); name=request.form.get('name','').strip()
    email=request.form.get('email','').strip(); pw=request.form.get('password','').strip()
    reason=request.form.get('reason','').strip()
    if not all([name,email,pw,reason]): flash('All fields including reason are required.','danger'); return redirect(url_for('ds_dashboard'))
    if User.query.filter_by(email=email).first(): flash('Email already in use.','danger'); return redirect(url_for('ds_dashboard'))
    user=User(name=name,email=email,password=generate_password_hash(pw),role=role)
    db.session.add(user); db.session.flush()
    if role=='customer': user.customer_id=f"CUS{user.id:04d}"
    db.session.commit()
    log_ds_audit('CREATE ACCOUNT',f"{name} ({email}) role={role}",reason,current_user.name)
    flash(f'Account created for {name}.','success'); return redirect(url_for('ds_dashboard'))

# ── SEED ───────────────────────────────────────────────────────────────────────────
def seed():
    if not User.query.filter_by(email='admin@autospares.com').first():
        db.session.add(User(name='Admin',email='admin@autospares.com',password=generate_password_hash('admin123'),role='company'))
    if not User.query.filter_by(email='data@autospares.com').first():
        db.session.add(User(name='Data Service',email='data@autospares.com',password=generate_password_hash('data123'),role='dataservice'))
    if Part.query.count()==0:
        for p in [
            dict(name='Brake Pad Set',brand='Bosch',category='Brakes',price=1200,stock=15,compatible='Honda City 2018-2022'),
            dict(name='Air Filter',brand='K&N',category='Engine',price=450,stock=3,compatible='Maruti Swift 2017-2023'),
            dict(name='Engine Oil Filter',brand='Mahle',category='Engine',price=280,stock=22,compatible='Hyundai i20 2014-2023'),
            dict(name='Spark Plug Set',brand='NGK',category='Ignition',price=960,stock=0,compatible='Toyota Innova 2016-2023'),
            dict(name='Clutch Plate',brand='Valeo',category='Transmission',price=3500,stock=7,compatible='Tata Nexon 2017-2023'),
            dict(name='Radiator',brand='Denso',category='Cooling',price=6800,stock=2,compatible='Honda City 2014-2022'),
            dict(name='Shock Absorber Pair',brand='Monroe',category='Suspension',price=4200,stock=5,compatible='Maruti Ertiga 2018-2023'),
            dict(name='Battery 55Ah',brand='Amaron',category='Electrical',price=5500,stock=9,compatible='All petrol cars upto 1500cc'),
            dict(name='Timing Belt Kit',brand='Gates',category='Engine',price=2800,stock=4,compatible='Ford EcoSport 2013-2021'),
            dict(name='Alternator',brand='Bosch',category='Electrical',price=8500,stock=1,compatible='Volkswagen Polo 2010-2022'),
        ]: db.session.add(Part(**p))
    db.session.commit()

with app.app_context():
    db.create_all()
    for u in User.query.filter_by(role='customer').all():
        if not u.customer_id: u.customer_id=f"CUS{u.id:04d}"
    db.session.commit(); seed()

if __name__=='__main__':
    # Load saved API key on startup
    ak=get_api_key()
    if ak: os.environ['ANTHROPIC_API_KEY']=ak
    print("AutoSpares v5 running at http://localhost:5000")
    app.run(debug=False,port=5000)
